export class MagicLinkUtil {
  static setPasswordSession = async ({}) => {};
}
